<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author hugo smet <hugo.smet@scarlet.be>
 */
$lang['__background_site__']   = 'Kleur voor de onderste ondergrond (achter de inhoud kader)';
$lang['__link__']              = 'Kleur voor algemene link';
$lang['__existing__']          = 'Kleur voor link naar bestaande pagina\'s.';
$lang['__missing__']           = 'Kleur voor link naar onbestaande pagina\'s';
$lang['__site_width__']        = 'Breedte van de max site (in gelijk welke eenheid: %, px, em,...)';
$lang['__sidebar_width__']     = 'Breedte van de zijbalk,  indien aanwezig  (in gelijk welke eenheid: %, px, em,...)';
$lang['__tablet_width__']      = 'Beneden de breedte van deze schermafmetingen schakelt de site over naar tablet modus.';
$lang['__phone_width__']       = 'Beneden de breedte van deze schermafmetingen schakelt de site over naar telefoon modus.';
