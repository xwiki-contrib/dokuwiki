<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author rnck <dokuwiki@rnck.de>
 */
$lang['connectfail']           = 'Konnte nicht zur Datenbank verbinden.';
$lang['userexists']            = 'Entschuldigung, es existiert bereits ein Nutzer mit diesem Login.';
$lang['usernotexists']         = 'Entschuldigung, dieser Nutzer existiert nicht.';
$lang['writefail']             = 'Konnte Nutzer-Daten nicht modifizieren. Bitte informiere einen Admin.';
