<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Philip Knack <p.knack@stollfuss.de>
 * @author Hella Breitkopf <hella.breitkopf@gmail.com>
 */
$lang['connectfail']           = 'LDAP-Verbindung scheitert: %s';
$lang['domainfail']            = 'LDAP kann Ihren Benutzer (DN) nicht finden';
