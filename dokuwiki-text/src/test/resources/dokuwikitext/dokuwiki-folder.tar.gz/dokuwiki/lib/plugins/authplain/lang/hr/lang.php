<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['userexists']            = 'Korisnik s tim korisničkim imenom već postoji.';
$lang['usernotexists']         = 'Nažalost korisnik ne postoji';
$lang['writefail']             = 'Ne mogu izmijeniti korisničke podatke. Molim obavijestite svog Wiki administratora';
$lang['protected']             = 'Podaci za korisnika %s su zaštićeni i ne mogu biti izmijenjeni ili obrisani.';
