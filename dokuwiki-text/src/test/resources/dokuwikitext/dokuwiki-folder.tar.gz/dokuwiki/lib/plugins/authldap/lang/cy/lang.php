<?php
/**
 * Welsh language file for authldap plugin
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */

$lang['connectfail']     = 'LDAP yn methu cysylltu: %s';
$lang['domainfail']       = 'LDAP yn methu darganfod eich defnyddiwr dn';

//Setup VIM: ex: et ts=4 :
