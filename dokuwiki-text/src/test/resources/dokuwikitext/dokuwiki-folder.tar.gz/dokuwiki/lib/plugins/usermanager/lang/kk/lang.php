<?php
/**
 * kazakh language file
 *
 * @author Nurgozha Kaliaskarov astana08@gmail.com
 */
$lang['user_id']               = 'Пайдаланушы';
$lang['user_pass']             = 'Шартты белгi';
$lang['user_mail']             = 'E-mail';
