<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Kiril <neohidra@gmail.com>
 */
$lang['userexists']            = 'Вече съществува потребител с избраното име.';
$lang['usernotexists']         = 'За съжаление потребителят не съществува.';
