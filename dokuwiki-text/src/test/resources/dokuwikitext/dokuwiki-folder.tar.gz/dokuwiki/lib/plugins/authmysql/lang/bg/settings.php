<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Kiril <neohidra@gmail.com>
 * @author Ivan Peltekov <ivan.peltekov@abv.bg>
 */
$lang['server']                = 'Вашият MySQL сървър';
$lang['user']                  = 'MySQL потребителско име';
$lang['password']              = 'Парола за горния потребител';
$lang['database']              = 'Име на базата от данни';
$lang['charset']               = 'Набор от знаци, който се ползва в базата от данни';
$lang['debug']                 = 'Показване на допълнителна debug информация';
$lang['checkPass']             = 'SQL заявка за проверка на паролите';
$lang['getUserInfo']           = 'SQL заявка за извличане на информация за потребителя н';
$lang['debug_o_0']             = 'не';
$lang['debug_o_1']             = 'само при грешка';
$lang['debug_o_2']             = 'за всяко SQL запитване';
