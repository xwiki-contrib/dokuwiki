<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'यो नामको प्रयोगकर्ता पहिले देखि रहेको छ।';
