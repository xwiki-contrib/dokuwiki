# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,seperated


slayerjain:$1$vW08pnm6$p1sSSpZLuwHGW98VCcEHi0:Shubham Jain:shubhamkjain@outlook.com:admin,user
demouser:$1$p46yTcq0$T2UY9kVww61XRjOaapNd31:Demo User:demo.user@domain.com:demo_group
ani:$1$ur9JSiGG$6pEp9bkQotYtCSbMz77gD1:Anirudh Jain:jainshubham78@gmail.com:demo_group
